package tpTAA_sportTracker.domain;

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */

public enum GenderEnum
{
	MAN, WOMAN;
}
